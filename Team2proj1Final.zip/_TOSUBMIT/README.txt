To see the implemented functionality of the DatabaseEngine and DBMS:
$ g++ dbmsTest.cpp -o dbT.o
$ ./dbT.o

or just run the included dbT.o
$ ./dbT.o


To test in console mode:
$ g++ dbmsConsole.cpp -o dbC.o
$ ./dbC.o

or just run the included dbC.o
$ ./dbC.o


Working Commands:
CREATE
INSERT
SHOW
WRITE
CLOSE
projection
renaming


